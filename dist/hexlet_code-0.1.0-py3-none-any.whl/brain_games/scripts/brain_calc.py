#!/usr/bin/env python3
from brain_games.games.calc import brain_calculator


def main():
    brain_calculator()


if __name__ == "__main__":
    main()
